let name = "Florian Beckerle";
hello(name);
function hello(name){
    console.log("Hallo " + name + "!");
};